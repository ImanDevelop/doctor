<?php

//verify.php

include('header.php');

include('class/Appointment.php');

$object = new Appointment;

if(isset($_GET["code"]))
{
    /*
	$object->query = "
	UPDATE patient_table 
	SET email_verify = 'Yes' 
	WHERE patient_verification_code = '".$_GET["code"]."'
	";

	$object->execute();

	$_SESSION['success_message'] = '<div class="alert alert-success">You Email has been verify, now you can login into system</div>';

	header('location:login.php');
    */
}
?><div class="container">
    <div class="row justify-content-md-center">
        <div class="col col-md-4">
            <?php
            if(isset($_SESSION["success_message"]))
            {
                echo $_SESSION["success_message"];
                unset($_SESSION["success_message"]);
            }
            ?>
            <span id="message"></span>
            <div class="card">
                <div class="card-header">Verify mobile number</div>
                <div class="card-body">
                    <form method="post" id="patient_verify_form">
                        <div class="form-group">
                            <label>Registered Phone Number</label>
                            <input type="text" name="patient_phone_no" id="patient_phone_no" class="form-control" required autofocus data-parsley-type="digits" data-parsley-trigger="keyup"  placeholder="Phone Number" />
                        </div>
                        <div class="form-group">
                            <label>OTP</label>
                            <input type="text" name="patient_verification_code" id="patient_verification_code" class="form-control" required autofocus data-parsley-type="digits" data-parsley-trigger="keyup"  placeholder="Phone Number" />
                        </div>
                        <div class="form-group text-center">
                            <input type="hidden" name="action" value="patient_register_verify" />
                            <input type="submit" name="patient_login_button" id="patient_login_button" class="btn btn-primary" value="Verify" />
                        </div>

                        <div class="form-group text-center">
                            <p><a href="register.php">Register</a></p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>



<?php


include('footer.php');

?>

<script>

    $(document).ready(function(){

        $('#patient_verify_form').parsley();

        $('#patient_verify_form').on('submit', function(event){

            event.preventDefault();

            if($('#patient_verify_form').parsley().isValid())
            {
                $.ajax({

                    url:"action.php",
                    method:"POST",
                    data:$(this).serialize(),
                    dataType:"json",
                    beforeSend:function()
                    {
                        $('#patient_login_button').attr('disabled', 'disabled');
                    },
                    success:function(data)
                    {
                        $('#patient_login_button').attr('disabled', false);

                        if(data.error != '')
                        {
                            $('#message').html(data.error);
                        }
                        else
                        {
                            window.location.href="dashboard.php";
                        }
                    }
                });
            }

        });

    });



</script>
